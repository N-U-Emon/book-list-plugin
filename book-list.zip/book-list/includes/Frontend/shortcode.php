<?php




function book_list_shortcode(){

    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
    $args = array(
        'post_type'      => 'book',
        'posts_per_page' => 8,
        'paged' => $paged
    );
    $loop = new WP_Query($args); ?>

<div class="container">
    <div class="row">
        <?php while ( $loop->have_posts() ) : $loop->the_post();  ?>

            <div class="col-md-3">
                <div class="content text-center">
                    <a href="<?php esc_url(the_permalink()); ?>" >
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" class="img-fluid mx-auto">
                        
                    </a>
                    <p class="mt-4">
                        <span class="fs-2 mb-4 d-block" >Price: &dollar;<?php echo esc_html( get_post_meta( get_the_ID(), 'price', true ) ) ?> </span>
                        <a href="<?php echo esc_url( get_post_meta(get_the_ID(), 'preview_file', true ) ) ?>" target="_blank" class="btn btn-danger" >Preview File</a>
                    </p>
                    <div class="lead mt-4 text-md-start"><?php the_excerpt(); ?></div>
                </div>
            </div>

        <?php
        endwhile;
        ?>
    </div>
    <div class="pagination  justify-content-center mt-4 mt-md-1">
        <?php
        $big = 999999999;
        echo paginate_links( array(
            'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
            'format' => '?paged=%#%',
            'current' => max( 1, get_query_var('paged') ),
            'total' => $loop->max_num_pages,
            'prev_text' => '&laquo;',
            'next_text' => '&raquo;'
            ) );
        ?>
    </div>
   
</div>
    <?php
    wp_reset_postdata();

}

add_shortcode( 'book-list', 'book_list_shortcode' );