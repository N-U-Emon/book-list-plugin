<?php


class book_list_widget extends WP_Widget {

    public function __construct(){

        parent::__construct(
            'book_list_widget',
            __('Recent Book List', 'book-list'),
            array(
                'description'        =>  __('Here you can add Book List', 'book-list'),
                'customize_selective_refresh' => true,
    
            )
        );
    }

    // Create the widget front-end

    public function widget( $args, $instance ) {
        global $post;

        $title = apply_filters( 'widget_title', $instance['title'] );

		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) {

			echo $args['before_title'] . $title  . $args['after_title'];

		}
		?>
        <div id="recent-book-list">
            <?php $posts = get_posts(array(
                'post_type'  => 'book',
            )); 

            foreach ($posts as $post) : setup_postdata($post); ?>
            
            <h6>
                <a title="List: <?php the_title(); ?>" href="<?php the_permalink(); ?>">
                    <?php the_title(); ?>
                </a>
            </h6>


            <?php endforeach; ?>
        </div>

        <?php
		echo $args['after_widget'];
	}

    // Create the widget back-end

    public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Book List', 'book-list' );
		?>
		<p>

		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'book-list' ); ?></label> 

		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">

		</p>

        <div id="recent-book-list">
            <?php $posts = get_posts(array(
                'post_type'  => 'book',
            )); 

            foreach ($posts as $post) : setup_postdata($post); ?>
            
            <h6>
                <a title="List: <?php the_title(); ?>" href="<?php the_permalink(); ?>">
                    <?php the_title(); ?>
                </a>
            </h6>


            <?php endforeach; ?>
        </div>

		<?php 
	}


    // Save the widget settings

    public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';

		return $instance;
	}

}