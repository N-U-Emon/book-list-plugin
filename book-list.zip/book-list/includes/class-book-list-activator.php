<?php



class book_list_activator{
    
}