<?php



class book_list_deactivator{
    
}