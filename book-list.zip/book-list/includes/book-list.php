<?php

    
    /*
    * except length for book post type text
    */ 

    if(!function_exists('book_list_desc_except_length'))
    {
        function book_list_desc_except_length($length){

            return 200;
    
        }
    }

    add_filter('excerpt_length','book_list_desc_except_length');


    /*
    * The code runs Register Post Type that name is book
    */ 

    if(!function_exists('book_list_post_type'))
    {
        function book_list_post_type(){


            $labels = array(
                'name'                  => _x( 'Books', 'Post Type General Name', 'book-list' ),
                'singular_name'         => _x( 'Book', 'Post Type Singular Name', 'book-list' ),
                'menu_name'             => __( 'Book', 'book-list' ),
                'name_admin_bar'        => __( 'Post Type', 'book-list' ),
                'archives'              => __( 'Item Archives', 'book-list' ),
                'attributes'            => __( 'Item Attributes', 'book-list' ),
                'parent_item_colon'     => __( 'Parent Item:', 'book-list' ),
                'all_items'             => __( 'All Book List', 'book-list' ),
                'add_new_item'          => __( 'Add New Book', 'book-list' ),
                'add_new'               => __( 'Add New', 'book-list' ),
                'new_item'              => __( 'New Item', 'book-list' ),
                'edit_item'             => __( 'Edit Item', 'book-list' ),
                'update_item'           => __( 'Update Item', 'book-list' ),
                'view_item'             => __( 'View Item', 'book-list' ),
                'view_items'            => __( 'View Items', 'book-list' ),
                'search_items'          => __( 'Search Item', 'book-list' ),
                'not_found'             => __( 'Not found', 'book-list' ),
                'not_found_in_trash'    => __( 'Not found in Trash', 'book-list' ),
                'featured_image'        => __( 'Featured Book Image', 'book-list' ),
                'set_featured_image'    => __( 'Set featured image', 'book-list' ),
                'remove_featured_image' => __( 'Remove featured image', 'book-list' ),
                'use_featured_image'    => __( 'Use as featured image', 'book-list' ),
                'insert_into_item'      => __( 'Insert into item', 'book-list' ),
                'uploaded_to_this_item' => __( 'Uploaded to this item', 'book-list' ),
                'items_list'            => __( 'Items list', 'book-list' ),
                'items_list_navigation' => __( 'Items list navigation', 'book-list' ),
                'filter_items_list'     => __( 'Filter items list', 'book-list' ),
            );
            $args = array(
                'label'                 => __( 'Book', 'book-list' ),
                'description'           => __( 'You can add book list here', 'book-list' ),
                'labels'                => $labels,
                'supports'              => array('title', 'editor', 'thumbnail'),	
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 30,
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => true,
                'exclude_from_search'   => false,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
                'menu_icon'             => 'dashicons-book-alt',
            );
            register_post_type( 'book', $args );
    
    
            
        }
    }

    add_action( 'init',  'book_list_post_type');


    
    /*
    * The code runs Register Custom Taxonomie that name is Genres
    */ 

    if(!function_exists('book_list_taxonomy_genres'))
    {
        function book_list_taxonomy_genres() {
            $labels = array(
                'name'              => _x( 'Genres', 'book-list' ),
                'singular_name'     => _x( 'Genre', 'book-list' ),
                'search_items'      => __( 'Search Genres' ),
                'all_items'         => __( 'All Genres' ),
                'parent_item'       => __( 'Parent Genre' ),
                'parent_item_colon' => __( 'Parent Genre:' ),
                'edit_item'         => __( 'Edit Genre' ),
                'update_item'       => __( 'Update Genre' ),
                'add_new_item'      => __( 'Add New Genre' ),
                'new_item_name'     => __( 'New Genre Name' ),
                'menu_name'         => __( 'Genres' ),
            );
            $args   = array(
                'hierarchical'      => true,
                'labels'            => $labels,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => [ 'slug' => 'genre' ],
            );
            register_taxonomy( 'genre', [ 'book' ], $args );
        }
    }
   
   add_action( 'init', 'book_list_taxonomy_genres' );

    /*
    * The code runs Register Custom Taxonomie that name is Author
    */ 

    if(!function_exists('book_list_taxonomy_author'))
    {
        function book_list_taxonomy_author() {
            $labels = array(
                'name'              => _x( 'Authors', 'book-list' ),
                'singular_name'     => _x( 'Author', 'book-list' ),
                'search_items'      => __( 'Search Authors' ),
                'all_items'         => __( 'All Author' ),
                'parent_item'       => __( 'Parent Author' ),
                'parent_item_colon' => __( 'Parent Author:' ),
                'edit_item'         => __( 'Edit Author' ),
                'update_item'       => __( 'Update Author' ),
                'add_new_item'      => __( 'Add New Author' ),
                'new_item_name'     => __( 'New Author Name' ),
                'menu_name'         => __( 'Author' ),
            );
            $args   = array(
                'hierarchical'      => true,
                'labels'            => $labels,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => [ 'slug' => 'author' ],
            );
            register_taxonomy( 'author', [ 'book' ], $args );
        }
    }


   add_action( 'init', 'book_list_taxonomy_author' );


    /*
    * The code runs Register Custom Taxonomie that name is Publisher
    */ 

    if(!function_exists('book_list_taxonomy_publisher'))
    {
        function book_list_taxonomy_publisher() {
            $labels = array(
                'name'              => _x( 'Publishers', 'book-list' ),
                'singular_name'     => _x( 'Publisher', 'book-list' ),
                'search_items'      => __( 'Search Publishers' ),
                'all_items'         => __( 'All Publishers' ),
                'parent_item'       => __( 'Parent Publisher' ),
                'parent_item_colon' => __( 'Parent Publisher:' ),
                'edit_item'         => __( 'Edit Publisher' ),
                'update_item'       => __( 'Update Publisher' ),
                'add_new_item'      => __( 'Add New Publisher' ),
                'new_item_name'     => __( 'New Publisher Name' ),
                'menu_name'         => __( 'Publisher' ),
            );
            $args   = array(
                'hierarchical'      => true,
                'labels'            => $labels,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => [ 'slug' => 'publisher' ],
            );
            register_taxonomy( 'publishers', [ 'book' ], $args );
        }
    
    }
    
    add_action( 'init', 'book_list_taxonomy_publisher' );
    

   /*
    * The custom fields code runs for Book post type
    */ 

    if(!function_exists('book_list_custom_field'))
    {
        function book_list_custom_field(){

            add_meta_box( 
                'book_price',
                __('Book Price', 'book-list'),
                 'book_list_price', 
                 'book',
                 'normal',
                 'low',
    
                
            );
            add_meta_box( 
                'preview_file',
                __('Preview File', 'book-list'),
                 'book_list_preview_file', 
                 'book',
                 'normal',
                 'low',
    
                
            );

        }
    }

    add_action('add_meta_boxes','book_list_custom_field');

    // Getting Values

    if(!function_exists('book_list_price'))
    {
        function book_list_price($post){
            ?>
                <p>
                    <label for="price">$</label>
                    <input type="number" name="price" id="price" value="<?php echo get_post_meta($post->ID, 'price', true )  ?>" class="regular-text">
                </p>
            <?php
        }
    }

    if(!function_exists('book_list_preview_file'))
    {
        function book_list_preview_file($post){
            ?>
                <p>
                    <input class="widefat file-upload" type="text" id="file" name="preview_file" value="<?php echo get_post_meta($post->ID, 'preview_file', true )  ?>" /> 
                    <br>
                    <button type="button" class="preview_file">Upload file</button>
                    
                </p>
            <?php
        }
    }

    // value save in database
    if(!function_exists('book_list_price_database_value'))
    {
        function book_list_price_database_value($post_id){

            if(isset($_POST['price']) || isset($_POST['preview_file']) ){

                update_post_meta( $post_id, 'price', $_POST['price']);
    
                update_post_meta( $post_id, 'preview_file', $_POST['preview_file']);
            }
            
        }
    }

    add_action('save_post','book_list_price_database_value');










    


   

    
    


