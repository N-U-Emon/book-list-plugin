<?php


if(!function_exists('book_list_deactivator'))
{
    class book_list_deactivator{
    
    }
}
