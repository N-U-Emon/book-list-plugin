<?php


if(!function_exists('book_list_activator'))
{
    class book_list_activator{
    
    }
}
