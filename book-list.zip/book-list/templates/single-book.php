<?php

    get_header();

?>

    
<?php if(have_posts()): ?>

<div class="book-list-single-container">
    <div class="row">
        
        <div class="col-12">
                <div class="book-list-content">
                    <h2 class="book-list-single-heading">
                        <?php the_title(); ?>  
                    </h2>
                    
                    <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="" class="book-list-single-image">
                        
                    </a>
                    <p class="book-list-price-preview-area">

                        <span class="book-list-price" > 
                            <?php esc_html_e( 'Price', 'book-list' ) ?> : &dollar;<?php echo esc_html( get_post_meta( get_the_ID(), 'price', true ) ) ?> 
                        </span>

                        <a href="<?php echo esc_url( get_post_meta(get_the_ID(), 'preview_file', true ) ) ?>" target="_blank" class="book-list-preview-file" >
                            <?php esc_html_e( 'Preview File', 'book-list' ) ?>
                        </a>
                        
                    </p>
                    <div class="book-list-text"><?php the_content(); ?></div>
                </div>
        </div>

        <?php else: ?>
            <h2><?php esc_html_e( 'No content here', 'book-list' ) ?></h2>
    </div>
</div>

<?php endif; ?>


<?php

 get_footer();


