<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="<?php bloginfo('charset') ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php the_title(); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">

</head>
<body>

    
<?php if(have_posts()): ?>

<div class="container">
    <div class="row">
        
        <div class="col-12">
                <div class="content text-center">
                    <h2 class="h2">
                        <a href="<?php esc_url(the_permalink()); ?>" class="text-decoration-none text-dark">
                            <?php the_title(); ?>
                        </a>
                    </h2>
                    <a href="<?php esc_url(the_permalink()); ?>" >
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" class="img-fluid mx-auto">
                        
                    </a>
                    <p class="mt-4">
                        <span class="fs-2 mb-4 d-block" >Price: &dollar;<?php echo esc_html( get_post_meta( get_the_ID(), 'price', true ) ) ?> </span>
                        <a href="<?php echo esc_url( get_post_meta(get_the_ID(), 'preview_file', true ) ) ?>" target="_blank" class="btn btn-danger" >Preview File</a>
                    </p>
                    <div class="lead mt-4 text-md-start"><?php the_content(); ?></div>
                </div>
        </div>

        <?php else: ?>
            <h2>No content here</h2>
    </div>
</div>

<?php endif; ?>



        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>


