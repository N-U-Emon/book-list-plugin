<?php

/**
 * 
 * Plugin Name:       Book List
 * Plugin URI:        #
 * Description:       This plugin you can use for store your book list in dashboard and display on page.
 * Version:           1.0.0
 * Author:            NN Emon
 * Author URI:        https://n-u-emon.github.io/mywebsite/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       book-list
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) or die( 'Hey, you can not access via direct the file' );



    define( 'BOOK_LIST_ASSETS_FLIES', plugin_dir_url( __FILE__ ) );


    /**
    * The code that runs during plugin activation.
    * This action is documented in includes/class-book-list-activator.php
    */

    if(!function_exists('book_list_activate'))
    {
        function book_list_activate(){

            require_once plugin_dir_path( __FILE__) . 'includes/class-book-list-activator.php';
    
            $activator = new book_list_activator;
    
        }
    }

    register_activation_hook( __FILE__,  'book_list_activate') ;

    
    /**
     * The code that runs during plugin deactivation.
     * This action is documented in includes/class-book-list-deactivator.php
     */
    
    if(!function_exists('book_list_deactivate'))
    {
        function book_list_deactivate() {


            require_once plugin_dir_path( __FILE__ ) . 'includes/class-book-list-deactivator.php';
    
            $deactivator = new book_list_deactivator; 
    
        }
    }

    register_deactivation_hook( __FILE__, 'book_list_deactivate') ;


    /**
     * the file runs for custom post type and file name is book-list.php
     */

 
    require_once plugin_dir_path( __FILE__ ) . 'includes/book-list.php';



    /**
     * templates for custom post type that name is book
     * 
     */

    if(!function_exists('book_list_custom_post_type_archive_template'))
    {
        function book_list_custom_post_type_archive_template( $archive_template ) {
            global $post;
       
            if ( is_post_type_archive ( 'book' ) ) {
                 $archive_template = dirname( __FILE__ ) . '/templates/archive-book.php';
            }
            return $archive_template;
       }
    }
   
   add_filter( 'archive_template', 'book_list_custom_post_type_archive_template' ) ;

   if(!function_exists('book_list_custom_post_type_single_template'))
   {
        function book_list_custom_post_type_single_template( $single_template ) {
            global $post;
    
            if ( 'book' === $post->post_type  ) {
                $single_template = dirname( __FILE__ ) . '/templates/single-book.php';
            }
            return $single_template;
        }
   }
   
   add_filter( 'single_template', 'book_list_custom_post_type_single_template' ) ;



    /**
     *ShortCode for acrhive page
     */
    require_once plugin_dir_path( __FILE__ ) . 'includes/Frontend/shortcode.php';

    /**
     *Widget
     */
    
    if(!function_exists('book_list_widget'))
    {
        function book_list_widget(){
        
            require_once plugin_dir_path( __FILE__ ) . 'includes/Widget/class-book-list-widget.php';
    
            $book_widget = new book_list_widget;
    
            register_widget($book_widget);
        }
    }

    add_action('widgets_init', 'book_list_widget');
    


    /**
     *Front-end Assets Files
     */

    if(!function_exists('book_list_forntend_assets_files_enqueue'))
    {
        function book_list_forntend_assets_files_enqueue(){

            // css
            wp_enqueue_style( 'book-list-style', BOOK_LIST_ASSETS_FLIES.'assets/css/style.css', array(), '1.0.0', 'all' );     

        }
    }

 
    add_action('wp_enqueue_scripts','book_list_forntend_assets_files_enqueue');

    /**
     *dashboard Assets Files
     */

    if(!function_exists('book_list_dashboard_assets_files_enqueue'))
    {
        function book_list_dashboard_assets_files_enqueue(){

            wp_enqueue_script('book-list-preview-file', BOOK_LIST_ASSETS_FLIES.'assets/js/preview_file.js', array('jquery') ,'1.0.0', true );
    
         }
    }

    add_action('admin_enqueue_scripts','book_list_dashboard_assets_files_enqueue');

        






   


    






